﻿using NUnit.Framework;

#if NET461
// ReSharper disable once CheckNamespace
[SetUpFixture]
public class PluginsDebugAssertSetupFixture : DebugAssertSetupFixture {}
#endif
